package com.example.friend.service;

import java.util.List;

import com.example.friend.entity.Friend;

public interface IFriendService {
	String  addFriendService(Friend friend);
	List<Long>  readFriendsContacts(Long phoneNumber);

}
