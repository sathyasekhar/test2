package com.example.customer.breaker;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.customer.feign.FriendFeign;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class CustomerCircuitBreaker {
	
	@Autowired
	FriendFeign  ffeign;
	
	@HystrixCommand(fallbackMethod = "findFriendsFallback")
	public List<Long>  findFriendsContacts(Long phoneNumber) {
		return  ffeign.getFriends(phoneNumber);
	}
	
	public  List<Long>  findFriendsFallback(Long phoneNumber) {
		System.out.println("====findFriendsFallback=====");
		return new  ArrayList<Long>();
	}

}
