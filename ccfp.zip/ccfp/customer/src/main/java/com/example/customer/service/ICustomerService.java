package com.example.customer.service;

import com.example.customer.dto.CustomerDto;
import com.example.customer.dto.LoginDTO;
import com.example.customer.dto.RegisterDTO;

public interface ICustomerService {
	
	boolean  registerCustomer(RegisterDTO  registerDto);
	
	boolean  loginCustomer(LoginDTO  loginDto);
	
	CustomerDto  readCustomer(Long phoneNumber);
}
